﻿namespace SANGSAN
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.ledsUserForm1 = new SANGSAN.ledsUserForm();
            this.taskUserForm1 = new SANGSAN.taskUserForm();
            this.settingUserForm1 = new SANGSAN.settingUserForm();
            this.workerUserForm1 = new SANGSAN.workerUserForm();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btnSetting = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btndot = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_number = new System.Windows.Forms.TextBox();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btnZ = new System.Windows.Forms.Button();
            this.btnY = new System.Windows.Forms.Button();
            this.btnX = new System.Windows.Forms.Button();
            this.btnW = new System.Windows.Forms.Button();
            this.btnV = new System.Windows.Forms.Button();
            this.btnU = new System.Windows.Forms.Button();
            this.btnT = new System.Windows.Forms.Button();
            this.btnS = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.btnQ = new System.Windows.Forms.Button();
            this.btnP = new System.Windows.Forms.Button();
            this.btnO = new System.Windows.Forms.Button();
            this.btnN = new System.Windows.Forms.Button();
            this.btnM = new System.Windows.Forms.Button();
            this.btnL = new System.Windows.Forms.Button();
            this.btnK = new System.Windows.Forms.Button();
            this.btnJ = new System.Windows.Forms.Button();
            this.btnI = new System.Windows.Forms.Button();
            this.btnH = new System.Windows.Forms.Button();
            this.btnG = new System.Windows.Forms.Button();
            this.btnF = new System.Windows.Forms.Button();
            this.btnE = new System.Windows.Forms.Button();
            this.btnD = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.btnB = new System.Windows.Forms.Button();
            this.btnA = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.ledsUserForm1);
            this.panel1.Controls.Add(this.taskUserForm1);
            this.panel1.Controls.Add(this.settingUserForm1);
            this.panel1.Controls.Add(this.workerUserForm1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1264, 590);
            this.panel1.TabIndex = 0;
            // 
            // ledsUserForm1
            // 
            this.ledsUserForm1.AutoSize = true;
            this.ledsUserForm1.BackColor = System.Drawing.Color.Pink;
            this.ledsUserForm1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ledsUserForm1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ledsUserForm1.Location = new System.Drawing.Point(0, 0);
            this.ledsUserForm1.Margin = new System.Windows.Forms.Padding(8);
            this.ledsUserForm1.Name = "ledsUserForm1";
            this.ledsUserForm1.Size = new System.Drawing.Size(1264, 590);
            this.ledsUserForm1.TabIndex = 3;
            // 
            // taskUserForm1
            // 
            this.taskUserForm1.BackColor = System.Drawing.Color.Pink;
            this.taskUserForm1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.taskUserForm1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.taskUserForm1.Location = new System.Drawing.Point(0, 0);
            this.taskUserForm1.Margin = new System.Windows.Forms.Padding(8);
            this.taskUserForm1.Name = "taskUserForm1";
            this.taskUserForm1.Size = new System.Drawing.Size(1264, 590);
            this.taskUserForm1.TabIndex = 1;
            // 
            // settingUserForm1
            // 
            this.settingUserForm1.BackColor = System.Drawing.Color.Pink;
            this.settingUserForm1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.settingUserForm1.Location = new System.Drawing.Point(0, 0);
            this.settingUserForm1.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.settingUserForm1.Name = "settingUserForm1";
            this.settingUserForm1.Size = new System.Drawing.Size(1264, 590);
            this.settingUserForm1.TabIndex = 0;
            // 
            // workerUserForm1
            // 
            this.workerUserForm1.BackColor = System.Drawing.Color.Pink;
            this.workerUserForm1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.workerUserForm1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.workerUserForm1.Location = new System.Drawing.Point(0, 0);
            this.workerUserForm1.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.workerUserForm1.Name = "workerUserForm1";
            this.workerUserForm1.Size = new System.Drawing.Size(1264, 590);
            this.workerUserForm1.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.btnSetting);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 590);
            this.panel2.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1264, 121);
            this.panel2.TabIndex = 1;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(897, 8);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(169, 43);
            this.button5.TabIndex = 3;
            this.button5.Text = "뉴업무화면";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(1083, 8);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(169, 43);
            this.button4.TabIndex = 2;
            this.button4.Text = "업무화면";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(196, 8);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(169, 43);
            this.button3.TabIndex = 1;
            this.button3.Text = "작업자등록";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // btnSetting
            // 
            this.btnSetting.Location = new System.Drawing.Point(12, 8);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Size = new System.Drawing.Size(169, 43);
            this.btnSetting.TabIndex = 0;
            this.btnSetting.Text = "환경설정";
            this.btnSetting.UseVisualStyleBackColor = true;
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.btndot);
            this.panel3.Controls.Add(this.btn0);
            this.panel3.Controls.Add(this.btnCancel);
            this.panel3.Controls.Add(this.btnOK);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.tb_number);
            this.panel3.Controls.Add(this.btn9);
            this.panel3.Controls.Add(this.btn8);
            this.panel3.Controls.Add(this.btn7);
            this.panel3.Controls.Add(this.btn6);
            this.panel3.Controls.Add(this.btn5);
            this.panel3.Controls.Add(this.btn4);
            this.panel3.Controls.Add(this.btn3);
            this.panel3.Controls.Add(this.btn2);
            this.panel3.Controls.Add(this.btn1);
            this.panel3.Controls.Add(this.btnZ);
            this.panel3.Controls.Add(this.btnY);
            this.panel3.Controls.Add(this.btnX);
            this.panel3.Controls.Add(this.btnW);
            this.panel3.Controls.Add(this.btnV);
            this.panel3.Controls.Add(this.btnU);
            this.panel3.Controls.Add(this.btnT);
            this.panel3.Controls.Add(this.btnS);
            this.panel3.Controls.Add(this.btnR);
            this.panel3.Controls.Add(this.btnQ);
            this.panel3.Controls.Add(this.btnP);
            this.panel3.Controls.Add(this.btnO);
            this.panel3.Controls.Add(this.btnN);
            this.panel3.Controls.Add(this.btnM);
            this.panel3.Controls.Add(this.btnL);
            this.panel3.Controls.Add(this.btnK);
            this.panel3.Controls.Add(this.btnJ);
            this.panel3.Controls.Add(this.btnI);
            this.panel3.Controls.Add(this.btnH);
            this.panel3.Controls.Add(this.btnG);
            this.panel3.Controls.Add(this.btnF);
            this.panel3.Controls.Add(this.btnE);
            this.panel3.Controls.Add(this.btnD);
            this.panel3.Controls.Add(this.btnC);
            this.panel3.Controls.Add(this.btnB);
            this.panel3.Controls.Add(this.btnA);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 656);
            this.panel3.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1264, 329);
            this.panel3.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(596, 197);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(60, 60);
            this.button2.TabIndex = 43;
            this.button2.Text = "DEL";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.BtnNumberClick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(660, 197);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(93, 60);
            this.button1.TabIndex = 42;
            this.button1.Text = "CLEAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.BtnNumberClick);
            // 
            // btndot
            // 
            this.btndot.Location = new System.Drawing.Point(530, 197);
            this.btndot.Name = "btndot";
            this.btndot.Size = new System.Drawing.Size(60, 60);
            this.btndot.TabIndex = 41;
            this.btndot.Text = ".";
            this.btndot.UseVisualStyleBackColor = true;
            this.btndot.Click += new System.EventHandler(this.BtnNumberClick);
            // 
            // btn0
            // 
            this.btn0.Location = new System.Drawing.Point(467, 197);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(60, 60);
            this.btn0.TabIndex = 40;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Click += new System.EventHandler(this.BtnNumberClick);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(1110, 206);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(142, 42);
            this.btnCancel.TabIndex = 39;
            this.btnCancel.Text = "취소";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(962, 206);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(142, 42);
            this.btnOK.TabIndex = 38;
            this.btnOK.Text = "확인";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(670, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 37);
            this.label1.TabIndex = 37;
            this.label1.Text = "수량";
            // 
            // tb_number
            // 
            this.tb_number.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb_number.Location = new System.Drawing.Point(773, 15);
            this.tb_number.Name = "tb_number";
            this.tb_number.Size = new System.Drawing.Size(479, 38);
            this.tb_number.TabIndex = 36;
            // 
            // btn9
            // 
            this.btn9.Location = new System.Drawing.Point(596, 134);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(60, 60);
            this.btn9.TabIndex = 35;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.BtnNumberClick);
            // 
            // btn8
            // 
            this.btn8.Location = new System.Drawing.Point(530, 134);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(60, 60);
            this.btn8.TabIndex = 34;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.BtnNumberClick);
            // 
            // btn7
            // 
            this.btn7.Location = new System.Drawing.Point(467, 134);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(60, 60);
            this.btn7.TabIndex = 33;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.BtnNumberClick);
            // 
            // btn6
            // 
            this.btn6.Location = new System.Drawing.Point(596, 71);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(60, 60);
            this.btn6.TabIndex = 32;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.BtnNumberClick);
            // 
            // btn5
            // 
            this.btn5.Location = new System.Drawing.Point(530, 71);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(60, 60);
            this.btn5.TabIndex = 31;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.BtnNumberClick);
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(467, 71);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(60, 60);
            this.btn4.TabIndex = 30;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.BtnNumberClick);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(596, 8);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(60, 60);
            this.btn3.TabIndex = 29;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.BtnNumberClick);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(530, 8);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(60, 60);
            this.btn2.TabIndex = 28;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.BtnNumberClick);
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(467, 8);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(60, 60);
            this.btn1.TabIndex = 27;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.BtnNumberClick);
            // 
            // btnZ
            // 
            this.btnZ.Location = new System.Drawing.Point(271, 197);
            this.btnZ.Name = "btnZ";
            this.btnZ.Size = new System.Drawing.Size(60, 60);
            this.btnZ.TabIndex = 26;
            this.btnZ.Text = "Z";
            this.btnZ.UseVisualStyleBackColor = true;
            // 
            // btnY
            // 
            this.btnY.Location = new System.Drawing.Point(205, 197);
            this.btnY.Name = "btnY";
            this.btnY.Size = new System.Drawing.Size(60, 60);
            this.btnY.TabIndex = 25;
            this.btnY.Text = "Y";
            this.btnY.UseVisualStyleBackColor = true;
            // 
            // btnX
            // 
            this.btnX.Location = new System.Drawing.Point(141, 197);
            this.btnX.Name = "btnX";
            this.btnX.Size = new System.Drawing.Size(60, 60);
            this.btnX.TabIndex = 24;
            this.btnX.Text = "X";
            this.btnX.UseVisualStyleBackColor = true;
            // 
            // btnW
            // 
            this.btnW.Location = new System.Drawing.Point(76, 197);
            this.btnW.Name = "btnW";
            this.btnW.Size = new System.Drawing.Size(60, 60);
            this.btnW.TabIndex = 23;
            this.btnW.Text = "W";
            this.btnW.UseVisualStyleBackColor = true;
            // 
            // btnV
            // 
            this.btnV.Location = new System.Drawing.Point(12, 197);
            this.btnV.Name = "btnV";
            this.btnV.Size = new System.Drawing.Size(60, 60);
            this.btnV.TabIndex = 22;
            this.btnV.Text = "V";
            this.btnV.UseVisualStyleBackColor = true;
            // 
            // btnU
            // 
            this.btnU.Location = new System.Drawing.Point(400, 134);
            this.btnU.Name = "btnU";
            this.btnU.Size = new System.Drawing.Size(60, 60);
            this.btnU.TabIndex = 21;
            this.btnU.Text = "U";
            this.btnU.UseVisualStyleBackColor = true;
            // 
            // btnT
            // 
            this.btnT.Location = new System.Drawing.Point(335, 134);
            this.btnT.Name = "btnT";
            this.btnT.Size = new System.Drawing.Size(60, 60);
            this.btnT.TabIndex = 20;
            this.btnT.Text = "T";
            this.btnT.UseVisualStyleBackColor = true;
            // 
            // btnS
            // 
            this.btnS.Location = new System.Drawing.Point(271, 134);
            this.btnS.Name = "btnS";
            this.btnS.Size = new System.Drawing.Size(60, 60);
            this.btnS.TabIndex = 19;
            this.btnS.Text = "S";
            this.btnS.UseVisualStyleBackColor = true;
            // 
            // btnR
            // 
            this.btnR.Location = new System.Drawing.Point(206, 134);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(60, 60);
            this.btnR.TabIndex = 18;
            this.btnR.Text = "R";
            this.btnR.UseVisualStyleBackColor = true;
            // 
            // btnQ
            // 
            this.btnQ.Location = new System.Drawing.Point(141, 134);
            this.btnQ.Name = "btnQ";
            this.btnQ.Size = new System.Drawing.Size(60, 60);
            this.btnQ.TabIndex = 17;
            this.btnQ.Text = "Q";
            this.btnQ.UseVisualStyleBackColor = true;
            // 
            // btnP
            // 
            this.btnP.Location = new System.Drawing.Point(76, 134);
            this.btnP.Name = "btnP";
            this.btnP.Size = new System.Drawing.Size(60, 60);
            this.btnP.TabIndex = 16;
            this.btnP.Text = "P";
            this.btnP.UseVisualStyleBackColor = true;
            // 
            // btnO
            // 
            this.btnO.Location = new System.Drawing.Point(11, 134);
            this.btnO.Name = "btnO";
            this.btnO.Size = new System.Drawing.Size(60, 60);
            this.btnO.TabIndex = 15;
            this.btnO.Text = "O";
            this.btnO.UseVisualStyleBackColor = true;
            // 
            // btnN
            // 
            this.btnN.Location = new System.Drawing.Point(400, 71);
            this.btnN.Name = "btnN";
            this.btnN.Size = new System.Drawing.Size(60, 60);
            this.btnN.TabIndex = 14;
            this.btnN.Text = "N";
            this.btnN.UseVisualStyleBackColor = true;
            this.btnN.Click += new System.EventHandler(this.btnN_Click);
            // 
            // btnM
            // 
            this.btnM.Location = new System.Drawing.Point(335, 71);
            this.btnM.Name = "btnM";
            this.btnM.Size = new System.Drawing.Size(60, 60);
            this.btnM.TabIndex = 13;
            this.btnM.Text = "M";
            this.btnM.UseVisualStyleBackColor = true;
            // 
            // btnL
            // 
            this.btnL.Location = new System.Drawing.Point(272, 71);
            this.btnL.Name = "btnL";
            this.btnL.Size = new System.Drawing.Size(60, 60);
            this.btnL.TabIndex = 12;
            this.btnL.Text = "L";
            this.btnL.UseVisualStyleBackColor = true;
            this.btnL.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnK
            // 
            this.btnK.Location = new System.Drawing.Point(207, 71);
            this.btnK.Name = "btnK";
            this.btnK.Size = new System.Drawing.Size(60, 60);
            this.btnK.TabIndex = 11;
            this.btnK.Text = "K";
            this.btnK.UseVisualStyleBackColor = true;
            // 
            // btnJ
            // 
            this.btnJ.Location = new System.Drawing.Point(142, 71);
            this.btnJ.Name = "btnJ";
            this.btnJ.Size = new System.Drawing.Size(60, 60);
            this.btnJ.TabIndex = 10;
            this.btnJ.Text = "J";
            this.btnJ.UseVisualStyleBackColor = true;
            // 
            // btnI
            // 
            this.btnI.Location = new System.Drawing.Point(77, 71);
            this.btnI.Name = "btnI";
            this.btnI.Size = new System.Drawing.Size(60, 60);
            this.btnI.TabIndex = 9;
            this.btnI.Text = "I";
            this.btnI.UseVisualStyleBackColor = true;
            // 
            // btnH
            // 
            this.btnH.Location = new System.Drawing.Point(12, 71);
            this.btnH.Name = "btnH";
            this.btnH.Size = new System.Drawing.Size(60, 60);
            this.btnH.TabIndex = 8;
            this.btnH.Text = "H";
            this.btnH.UseVisualStyleBackColor = true;
            // 
            // btnG
            // 
            this.btnG.Location = new System.Drawing.Point(402, 8);
            this.btnG.Name = "btnG";
            this.btnG.Size = new System.Drawing.Size(60, 60);
            this.btnG.TabIndex = 6;
            this.btnG.Text = "G";
            this.btnG.UseVisualStyleBackColor = true;
            // 
            // btnF
            // 
            this.btnF.Location = new System.Drawing.Point(337, 8);
            this.btnF.Name = "btnF";
            this.btnF.Size = new System.Drawing.Size(60, 60);
            this.btnF.TabIndex = 5;
            this.btnF.Text = "F";
            this.btnF.UseVisualStyleBackColor = true;
            // 
            // btnE
            // 
            this.btnE.Location = new System.Drawing.Point(272, 8);
            this.btnE.Name = "btnE";
            this.btnE.Size = new System.Drawing.Size(60, 60);
            this.btnE.TabIndex = 4;
            this.btnE.Text = "E";
            this.btnE.UseVisualStyleBackColor = true;
            // 
            // btnD
            // 
            this.btnD.Location = new System.Drawing.Point(207, 8);
            this.btnD.Name = "btnD";
            this.btnD.Size = new System.Drawing.Size(60, 60);
            this.btnD.TabIndex = 3;
            this.btnD.Text = "D";
            this.btnD.UseVisualStyleBackColor = true;
            // 
            // btnC
            // 
            this.btnC.Location = new System.Drawing.Point(142, 8);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(60, 60);
            this.btnC.TabIndex = 2;
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = true;
            // 
            // btnB
            // 
            this.btnB.Location = new System.Drawing.Point(77, 8);
            this.btnB.Name = "btnB";
            this.btnB.Size = new System.Drawing.Size(60, 60);
            this.btnB.TabIndex = 1;
            this.btnB.Text = "B";
            this.btnB.UseVisualStyleBackColor = true;
            // 
            // btnA
            // 
            this.btnA.Location = new System.Drawing.Point(12, 8);
            this.btnA.Name = "btnA";
            this.btnA.Size = new System.Drawing.Size(60, 60);
            this.btnA.TabIndex = 0;
            this.btnA.Text = "A";
            this.btnA.UseVisualStyleBackColor = true;
            this.btnA.Click += new System.EventHandler(this.btnA_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1264, 985);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnSetting;
        private System.Windows.Forms.Button btnZ;
        private System.Windows.Forms.Button btnY;
        private System.Windows.Forms.Button btnX;
        private System.Windows.Forms.Button btnW;
        private System.Windows.Forms.Button btnV;
        private System.Windows.Forms.Button btnU;
        private System.Windows.Forms.Button btnT;
        private System.Windows.Forms.Button btnS;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnQ;
        private System.Windows.Forms.Button btnP;
        private System.Windows.Forms.Button btnO;
        private System.Windows.Forms.Button btnN;
        private System.Windows.Forms.Button btnM;
        private System.Windows.Forms.Button btnL;
        private System.Windows.Forms.Button btnK;
        private System.Windows.Forms.Button btnJ;
        private System.Windows.Forms.Button btnI;
        private System.Windows.Forms.Button btnH;
        private System.Windows.Forms.Button btnG;
        private System.Windows.Forms.Button btnF;
        private System.Windows.Forms.Button btnE;
        private System.Windows.Forms.Button btnD;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Button btnB;
        private System.Windows.Forms.Button btnA;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.TextBox tb_number;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btndot;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private workerUserForm workerUserForm1;
        private taskUserForm taskUserForm1;
        private settingUserForm settingUserForm1;
        private System.Windows.Forms.Button button5;
        private ledsUserForm ledsUserForm1;
    }
}

