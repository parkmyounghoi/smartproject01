﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SANGSAN
{
    class BindingDatas
    {
        public static int tag_num = 0;
        public static string http_url = "http://192.168.0.43";
    }
}
